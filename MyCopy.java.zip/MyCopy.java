package ass4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.util.Scanner;
import java.io.IOException;

public class MyCopy {

	public static void  main(String[] args) throws InterruptedException, IOException {
		

		File source = new File(args[0]
				);

		File dest = new File(args[1]);

		// copy file using FileStreams

		long start = System.nanoTime();

		long end;

	
		
			        copyFileUsingFileChannels(source, dest);
		
			        end = System.nanoTime();
		
			        System.out.println("Time taken by FileChannels Copy = " + (end - start));
	}

	private static void copyFileUsingFileStreams(File source, File dest)

	throws IOException {

		InputStream input = new FileInputStream(source);;

		OutputStream output = new FileOutputStream(dest);

		try {

			/*input = new FileInputStream(source);

			output = new FileOutputStream(dest);*/

			byte[] buf = new byte[1024];

			int bytesRead;

			while ((bytesRead = input.read(buf)) >= 0) {

				output.write(buf, 0, bytesRead);

			}

		} finally {
              
			input.close();

			output.close();

		}

	}
	 private static void copyFileUsingFileChannels(File source, File dest) throws IOException {
	 
	 	        FileChannel inputChannel = new FileInputStream(source).getChannel();
	 	  	 
	 
	 	        FileChannel outputChannel = new FileOutputStream(dest).getChannel();
	 
	 	        try {
	 
	 	            
	 	            
	 
	 	            outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
	 
	 	        } finally {
	 
	 	            inputChannel.close();
	 
	 	            outputChannel.close();
	 
	 	        }
	 
	 	    }

	
}


